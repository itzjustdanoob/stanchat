const express = require('express');
const cors = require('cors');
require('dotenv').config();

const postsRouter = require('./routes/posts');
const usersRouter = require('./routes/users');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

app.use('/api/posts', postsRouter);
app.use('/api/users', usersRouter);

app.get('/', (req, res) => {
  res.json({ message: 'StanChat backend is alive! 🔥' });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
